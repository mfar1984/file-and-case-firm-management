<?php

return [
    /*
    |--------------------------------------------------------------------------
    | DDoS Protection Configuration
    |--------------------------------------------------------------------------
    |
    | This file contains the configuration for DDoS protection middleware
    | and Shieldon firewall settings with advanced Layer 7 protection.
    |
    */

    'enabled' => env('DDOS_PROTECTION_ENABLED', true),

    'rate_limiting' => [
        'requests_per_minute' => env('DDOS_RATE_LIMIT_PER_MINUTE', 60),
        'requests_per_hour' => env('DDOS_RATE_LIMIT_PER_HOUR', 1000),
        'block_duration' => env('DDOS_BLOCK_DURATION', 3600), // 1 hour in seconds
        'concurrent_connections' => env('DDOS_CONCURRENT_CONNECTIONS', 5), // Max concurrent connections per IP
    ],

    'shieldon' => [
        'enabled' => env('SHIELDON_ENABLED', true),
        'data_directory' => storage_path('shieldon'),
        'time_unit_quota' => [
            's' => 3,   // 3 requests per second
            'm' => 60,  // 60 requests per minute
            'h' => 300, // 300 requests per hour
        ],
        'data_circle' => [
            's' => 60,  // Store 60 seconds of data
            'm' => 60,  // Store 60 minutes of data
            'h' => 24,  // Store 24 hours of data
        ],
    ],

    // Advanced Layer 7 DDoS Protection
    'layer7_protection' => [
        'enabled' => env('DDOS_LAYER7_PROTECTION_ENABLED', true),
        
        // HTTP Flood Protection
        'http_flood' => [
            'enabled' => true,
            'max_requests_per_10s' => 20,        // Max requests per 10 seconds
            'max_concurrent_connections' => 5,   // Max concurrent connections
            'block_duration' => 7200,            // Block for 2 hours
        ],
        
        // Session Protection
        'session_protection' => [
            'enabled' => true,
            'max_session_attempts' => 10,        // Max session attempts per 5 minutes
            'max_session_creations' => 5,        // Max session creations per minute
            'block_duration' => 3600,            // Block for 1 hour
        ],
        
        // Header Validation
        'header_validation' => [
            'enabled' => true,
            'block_suspicious_headers' => true,  // Block suspicious headers
            'block_duration' => 3600,            // Block for 1 hour
        ],
        
        // Payload Analysis
        'payload_analysis' => [
            'enabled' => true,
            'scan_request_body' => true,         // Scan request body
            'scan_query_string' => true,         // Scan query string
            'scan_url_path' => true,             // Scan URL path
            'block_duration' => 3600,            // Block for 1 hour
        ],
        
        // Progressive Blocking
        'progressive_blocking' => [
            'enabled' => true,
            'base_duration' => 3600,             // Base block duration (1 hour)
            'max_duration' => 86400,             // Maximum block duration (24 hours)
            'multiplier' => 2,                   // Duration multiplier per violation
        ],
    ],

    'suspicious_patterns' => [
        // Directory traversal
        '/\.\./', '/\.\.%2f/', '/\.\.%5c/', '/\.\.\\/',
        
        // SQL injection
        '/union\s+select/i', '/select\s+.*\s+from/i', '/insert\s+into/i', 
        '/update\s+.*\s+set/i', '/delete\s+from/i', '/drop\s+table/i', 
        '/create\s+table/i', '/alter\s+table/i', '/exec\s*\(/i',
        
        // XSS attempts
        '/<script/i', '/javascript:/i', '/on\w+\s*=/i', '/vbscript:/i',
        
        // Code injection
        '/eval\s*\(/i', '/system\s*\(/i', '/shell_exec/i', '/passthru/i',
        
        // File inclusion
        '/include\s*\(/i', '/require\s*\(/i', '/include_once/i', '/require_once/i',
        
        // PHP code
        '/<\?php/i', '/<\?=/i', '/<\?/i',
        
        // Common attack paths
        '/\.env/', '/\.git/', '/phpinfo/', '/wp-admin/', '/admin/',
        '/config/', '/backup/', '/db/', '/database/', '/sql/',
    ],

    'suspicious_user_agents' => [
        'bot', 'crawler', 'spider', 'scraper', 'curl', 'wget',
        'python', 'java', 'perl', 'ruby', 'php', 'node', 'go',
        'masscan', 'nmap', 'sqlmap', 'nikto', 'dirb', 'gobuster'
    ],

    'whitelist' => [
        // Add trusted IP addresses here
        // '127.0.0.1',
        // '::1',
        // '192.168.1.0/24', // Local network
    ],

    'blacklist' => [
        // Add known malicious IP addresses here
        // '1.2.3.4',
        // '5.6.7.8',
    ],

    'logging' => [
        'enabled' => env('DDOS_LOGGING_ENABLED', true),
        'channel' => env('DDOS_LOG_CHANNEL', 'daily'),
        'level' => env('DDOS_LOG_LEVEL', 'warning'), // debug, info, warning, error
        'log_blocked_ips' => true,
        'log_suspicious_activity' => true,
        'log_rate_limit_violations' => true,
    ],

    // Geographic blocking (optional)
    'geographic_blocking' => [
        'enabled' => env('DDOS_GEO_BLOCKING_ENABLED', false),
        'blocked_countries' => [
            // Add country codes to block
            // 'CN', 'RU', 'KP', 'IR',
        ],
        'allowed_countries' => [
            // Add country codes to allow (if empty, all countries allowed)
            // 'MY', 'SG', 'US', 'GB',
        ],
    ],

    // Advanced monitoring
    'monitoring' => [
        'enabled' => env('DDOS_MONITORING_ENABLED', true),
        'alert_threshold' => env('DDOS_ALERT_THRESHOLD', 100), // Requests per minute to trigger alert
        'stats_retention' => env('DDOS_STATS_RETENTION', 30),  // Days to keep statistics
    ],
]; 