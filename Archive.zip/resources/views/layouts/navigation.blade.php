<div class="flex min-h-screen">
    @component('components.sidebar')
    @endcomponent
    <!-- Main Content -->
    <div class="flex-1">
        <!-- Old navigation removed; content will be rendered here -->
    </div>
            </div>
