<svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" class="h-9 w-auto" style="background:white;">
    <circle cx="24" cy="24" r="24" fill="white"/>
    <text x="50%" y="55%" text-anchor="middle" fill="#222" font-size="20" font-family="Poppins, Arial, sans-serif" dy=".3em">NF</text>
</svg>
<?php /**PATH /Users/faizan/Documents/Faizan/Programming/Naeelah Firm/resources/views/components/application-logo.blade.php ENDPATH**/ ?>