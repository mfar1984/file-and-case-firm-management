<?php $__env->startSection('breadcrumb'); ?>
    Settings > Category Management > Edit Category
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="px-4 md:px-6 pt-4 md:pt-6 pb-6 max-w-7xl mx-auto">
    <div class="bg-white rounded shadow-md border border-gray-300">
        <div class="p-4 md:p-6 border-b border-gray-200">
            <div class="flex justify-between items-start">
                <div>
                    <div class="flex items-center">
                        <div class="h-10 w-10 rounded-full flex items-center justify-center mr-3" style="background-color: <?php echo e($category->color); ?>20; border: 2px solid <?php echo e($category->color); ?>">
                            <?php if($category->icon): ?>
                                <span class="text-lg font-medium" style="color: <?php echo e($category->color); ?>"><?php echo e($category->icon); ?></span>
                            <?php else: ?>
                                <span class="text-lg font-medium" style="color: <?php echo e($category->color); ?>"><?php echo e(substr($category->name, 0, 1)); ?></span>
                            <?php endif; ?>
                        </div>
                        <div>
                            <h1 class="text-lg md:text-xl font-bold text-gray-800">Edit Category</h1>
                            <p class="text-xs text-gray-500 mt-1"><?php echo e($category->name); ?> (<?php echo e(ucfirst($category->type)); ?>)</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="p-4 md:p-6">
            <form action="<?php echo e(route('settings.category.update', $category->id)); ?>" method="POST" class="space-y-0">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                
                <!-- Basic Information Section -->
                <div class="bg-gray-50 p-4 rounded-lg mb-6">
                    <h3 class="text-sm font-semibold text-gray-700 mb-4">Basic Information</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-medium text-gray-700 mb-2">Category Name *</label>
                            <input type="text" name="name" required 
                                   value="<?php echo e(old('name', $category->name)); ?>"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md text-xs focus:outline-none focus:ring-2 focus:ring-blue-500" 
                                   placeholder="e.g., Criminal Cases, Civil Actions">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <label class="block text-xs font-medium text-gray-700 mb-2">Category Type *</label>
                            <select name="type" required 
                                    class="w-full px-3 py-2 border border-gray-300 rounded-md text-xs focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <option value="">Select Type</option>
                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>" <?php echo e(old('type', $category->type) == $key ? 'selected' : ''); ?>>
                                        <?php echo e($label); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="md:col-span-2">
                            <label class="block text-xs font-medium text-gray-700 mb-2">Description</label>
                            <textarea name="description" rows="3" 
                                      class="w-full px-3 py-2 border border-gray-300 rounded-md text-xs focus:outline-none focus:ring-2 focus:ring-blue-500" 
                                      placeholder="Brief description of this category..."><?php echo e(old('description', $category->description)); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <!-- Visual Settings Section -->
                <div class="bg-gray-50 p-4 rounded-lg mb-6">
                    <h3 class="text-sm font-semibold text-gray-700 mb-4">Visual Settings</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-medium text-gray-700 mb-2">Color *</label>
                            <input type="color" name="color" required 
                                   value="<?php echo e(old('color', $category->color)); ?>"
                                   class="w-full h-10 border border-gray-300 rounded-md text-xs focus:outline-none focus:ring-2 focus:ring-blue-500">
                            <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <label class="block text-xs font-medium text-gray-700 mb-2">Icon (Optional)</label>
                            <input type="text" name="icon" 
                                   value="<?php echo e(old('icon', $category->icon)); ?>"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md text-xs focus:outline-none focus:ring-2 focus:ring-blue-500" 
                                   placeholder="e.g., folder, description, person">
                            <p class="text-xs text-gray-500 mt-1">Material Icons name (optional)</p>
                            <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <label class="block text-xs font-medium text-gray-700 mb-2">Sort Order</label>
                            <input type="number" name="sort_order" 
                                   value="<?php echo e(old('sort_order', $category->sort_order)); ?>"
                                   min="0"
                                   class="w-full px-3 py-2 border border-gray-300 rounded-md text-xs focus:outline-none focus:ring-2 focus:ring-blue-500" 
                                   placeholder="0">
                            <p class="text-xs text-gray-500 mt-1">Lower numbers appear first</p>
                            <?php $__errorArgs = ['sort_order'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <!-- Status Section -->
                <div class="bg-gray-50 p-4 rounded-lg mb-6">
                    <h3 class="text-sm font-semibold text-gray-700 mb-4">Status</h3>
                    <div class="space-y-4">
                        <div class="flex items-center">
                            <input type="checkbox" name="is_active" value="1" 
                                   id="is_active"
                                   <?php echo e(old('is_active', $category->is_active) ? 'checked' : ''); ?>

                                   class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                            <label for="is_active" class="ml-2 text-xs text-gray-700">
                                Category is active and visible
                            </label>
                        </div>
                    </div>
                </div>

                <!-- Current Category Information -->
                <div class="bg-blue-50 p-4 rounded-lg mb-6 border border-blue-200">
                    <h3 class="text-sm font-semibold text-blue-700 mb-4">Current Category Information</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                        <div>
                            <span class="text-blue-600">Created:</span>
                            <div class="text-blue-800"><?php echo e($category->created_at->format('d M Y H:i')); ?></div>
                        </div>
                        <div>
                            <span class="text-blue-600">Last Updated:</span>
                            <div class="text-blue-800"><?php echo e($category->updated_at->format('d M Y H:i')); ?></div>
                        </div>
                        <div>
                            <span class="text-blue-600">Items Count:</span>
                            <div class="text-blue-800"><?php echo e($category->item_count); ?> items</div>
                        </div>
                    </div>
                </div>

                <!-- Form Actions -->
                <div class="flex justify-end space-x-3 pt-4 border-t border-gray-200">
                    <a href="<?php echo e(route('settings.category.show', $category->id)); ?>" 
                       class="px-4 py-2 border border-gray-300 rounded-md text-xs font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        Cancel
                    </a>
                    <button type="submit" 
                            class="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md text-xs font-medium focus:outline-none focus:ring-2 focus:ring-blue-500">
                        Update Category
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/faizan/Documents/Faizan/Programming/Naeelah Firm/resources/views/settings/category-edit.blade.php ENDPATH**/ ?>