<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Shieldon\Firewall\Firewall;
use Shieldon\Firewall\Captcha\Csrf;
use Symfony\Component\HttpFoundation\Response;

class DdosProtectionMiddleware
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next)
    {
        // Get client IP
        $clientIp = $request->ip();
        
        // Get DDoS settings from database
        $ddosSettings = $this->getDdosSettings();
        
        // Check if DDoS protection is enabled
        if (!$ddosSettings['enabled']) {
            return $next($request);
        }
        
        // 1. Advanced Rate Limiting with Dynamic Limits
        if ($this->isAdvancedRateLimited($clientIp, $ddosSettings)) {
            Log::warning('DDoS Protection: Advanced rate limit exceeded for IP: ' . $clientIp);
            return $this->createRateLimitResponse();
        }

        // 2. HTTP Flood Protection
        if ($this->isHttpFlood($request, $clientIp)) {
            Log::warning('DDoS Protection: HTTP flood detected from IP: ' . $clientIp);
            $this->blockIp($clientIp, 'http_flood', 7200); // Block for 2 hours
            return $this->createBlockedResponse('HTTP flood detected');
        }

        // 3. Session Protection
        if ($this->isSessionAttack($request, $clientIp)) {
            Log::warning('DDoS Protection: Session attack detected from IP: ' . $clientIp);
            $this->blockIp($clientIp, 'session_attack', 3600);
            return $this->createBlockedResponse('Session attack detected');
        }

        // 4. Header Validation
        if ($this->hasMaliciousHeaders($request)) {
            Log::warning('DDoS Protection: Malicious headers detected from IP: ' . $clientIp);
            $this->blockIp($clientIp, 'malicious_headers', 3600);
            return $this->createBlockedResponse('Malicious headers detected');
        }

        // 5. Payload Analysis
        if ($this->hasMaliciousPayload($request)) {
            Log::warning('DDoS Protection: Malicious payload detected from IP: ' . $clientIp);
            $this->blockIp($clientIp, 'malicious_payload', 3600);
            return $this->createBlockedResponse('Malicious payload detected');
        }

        // 6. Check for suspicious patterns
        if ($this->isSuspiciousRequest($request)) {
            Log::warning('DDoS Protection: Suspicious request detected from IP: ' . $clientIp);
            $this->blockIp($clientIp, 'suspicious_pattern', 3600);
            return $this->createBlockedResponse('Suspicious activity detected');
        }

        // 7. Enhanced Shieldon Firewall
        if ($ddosSettings['shieldon']['enabled']) {
            // Temporarily disabled due to Shieldon setup issues
            // $firewallResponse = $this->processShieldonFirewall($request, $clientIp, $ddosSettings);
            // if ($firewallResponse !== null) {
            //     return $firewallResponse;
            // }
        }

        // 8. Progressive Rate Limiting
        $this->updateProgressiveRateLimit($clientIp);

        return $next($request);
    }

    /**
     * Get DDoS settings from database
     */
    private function getDdosSettings(): array
    {
        try {
            $ddosSetting = app(\App\Models\DdosSetting::class);
            return $ddosSetting::getNestedStructure();
        } catch (\Exception $e) {
            Log::error('DDoS Protection: Error loading settings, using defaults', ['error' => $e->getMessage()]);
            return [
                'enabled' => true,
                'rate_limiting' => [
                    'requests_per_minute' => 60,
                    'requests_per_hour' => 1000,
                    'block_duration' => 3600,
                ],
                'shieldon' => ['enabled' => false],
                'logging' => ['enabled' => true]
            ];
        }
    }

    /**
     * Advanced Rate Limiting with Dynamic Limits
     */
    private function isAdvancedRateLimited(string $ip, array $settings): bool
    {
        $minuteKey = 'rate_limit_minute:' . $ip;
        $hourKey = 'rate_limit_hour:' . $ip;
        
        $requestsPerMinute = Cache::get($minuteKey, 0);
        $requestsPerHour = Cache::get($hourKey, 0);
        
        $minuteLimit = (int) $settings['rate_limiting']['requests_per_minute'];
        $hourLimit = (int) $settings['rate_limiting']['requests_per_hour'];
        
        if ($requestsPerMinute >= $minuteLimit || $requestsPerHour >= $hourLimit) {
            return true;
        }
        
        Cache::put($minuteKey, $requestsPerMinute + 1, 60);
        Cache::put($hourKey, $requestsPerHour + 1, 3600);
        
        return false;
    }

    /**
     * HTTP Flood Protection
     */
    private function isHttpFlood(Request $request, string $ip): bool
    {
        $key = 'http_flood:' . $ip;
        $requests = Cache::get($key, 0);
        
        // Check for rapid successive requests
        if ($requests > 20) { // More than 20 requests in 10 seconds
            return true;
        }
        
        // Check for concurrent connections
        $concurrentKey = 'concurrent:' . $ip;
        $concurrent = Cache::get($concurrentKey, 0);
        
        if ($concurrent > 5) { // More than 5 concurrent connections
            return true;
        }
        
        Cache::put($key, $requests + 1, 10);
        Cache::put($concurrentKey, $concurrent + 1, 5);
        
        return false;
    }

    /**
     * Session Protection
     */
    private function isSessionAttack(Request $request, string $ip): bool
    {
        // Check for session fixation attempts
        if ($request->hasSession() && $request->session()->has('_token')) {
            $sessionKey = 'session_attempts:' . $ip;
            $attempts = Cache::get($sessionKey, 0);
            
            if ($attempts > 10) { // More than 10 session attempts
                return true;
            }
            
            Cache::put($sessionKey, $attempts + 1, 300);
        }
        
        // Check for rapid session creation
        $sessionCreationKey = 'session_creation:' . $ip;
        $creations = Cache::get($sessionCreationKey, 0);
        
        if ($creations > 5) { // More than 5 session creations per minute
            return true;
        }
        
        Cache::put($sessionCreationKey, $creations + 1, 60);
        
        return false;
    }

    /**
     * Header Validation
     */
    private function hasMaliciousHeaders(Request $request): bool
    {
        // Whitelist localhost and common legitimate IPs
        $clientIp = $request->ip();
        if (in_array($clientIp, ['127.0.0.1', '::1', 'localhost'])) {
            return false; // Allow localhost requests
        }
        
        // Only check for obviously malicious headers
        $maliciousHeaders = [
            'User-Agent' => [
                '/bot|crawler|spider|scraper/i', // Block obvious bots
                '/curl|wget|python|java|perl|ruby|php/i', // Block automation tools
            ],
            'X-Forwarded-For' => [
                '/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/', // Validate IP format
            ],
        ];
        
        foreach ($maliciousHeaders as $header => $patterns) {
            $value = $request->header($header);
            if ($value) {
                foreach ($patterns as $pattern) {
                    if (preg_match($pattern, $value)) {
                        // Only block if it's clearly malicious
                        if ($header === 'User-Agent' && preg_match('/bot|crawler|spider|scraper|curl|wget/i', $value)) {
                            return true;
                        }
                        // For X-Forwarded-For, only block if it's clearly spoofed
                        if ($header === 'X-Forwarded-For' && !filter_var($value, FILTER_VALIDATE_IP)) {
                            return true;
                        }
                    }
                }
            }
        }
        
        return false;
    }

    /**
     * Payload Analysis
     */
    private function hasMaliciousPayload(Request $request): bool
    {
        // Whitelist localhost
        $clientIp = $request->ip();
        if (in_array($clientIp, ['127.0.0.1', '::1', 'localhost'])) {
            return false; // Allow localhost requests
        }
        
        // Only check for clearly malicious patterns
        $maliciousPatterns = [
            // SQL Injection - only obvious patterns
            '/union\s+select.*from/i',
            '/drop\s+table/i',
            '/delete\s+from.*where/i',
            '/insert\s+into.*values/i',
            
            // XSS - only script tags and javascript
            '/<script[^>]*>/i',
            '/javascript:/i',
            
            // Command Injection - only system calls
            '/system\s*\(/i',
            '/exec\s*\(/i',
            '/shell_exec\s*\(/i',
            '/passthru\s*\(/i',
            
            // Directory Traversal - only obvious patterns
            '/\.\.\/\.\.\//',
            '/\.\.\\\.\.\\/',
            
            // File Inclusion - only PHP includes
            '/include\s*\(.*\.php/i',
            '/require\s*\(.*\.php/i',
            
            // PHP Code - only PHP tags
            '/<\?php/i',
            '/<\?=/i',
        ];
        
        $payload = $request->getContent() . $request->getQueryString() . $request->path();
        
        foreach ($maliciousPatterns as $pattern) {
            if (preg_match($pattern, $payload)) {
                return true;
            }
        }
        
        return false;
    }

    /**
     * Enhanced Suspicious Request Detection
     */
    private function isSuspiciousRequest(Request $request): bool
    {
        // Whitelist localhost
        $clientIp = $request->ip();
        if (in_array($clientIp, ['127.0.0.1', '::1', 'localhost'])) {
            return false; // Allow localhost requests
        }
        
        $suspiciousPatterns = [
            '/\.\.\/\.\./',     // Directory traversal (only obvious)
            '/union\s+select.*from/i', // SQL injection (only obvious)
            '/<script[^>]*>/i', // XSS attempts (only script tags)
            '/eval\s*\(/i',     // Code injection
            '/system\s*\(/i',   // Command injection
            '/\.env/',          // Environment file access
            '/\.git/',          // Git directory access
            '/phpinfo/',        // PHP info access
            '/wp-admin/',       // WordPress admin
            '/admin/',          // Admin panel access
        ];

        $userAgent = $request->header('User-Agent', '');
        $path = $request->path();
        $query = $request->getQueryString() ?? '';

        // Check for suspicious User-Agent - only obvious bots
        $suspiciousUserAgents = [
            'bot', 'crawler', 'spider', 'scraper', 'curl', 'wget'
        ];

        foreach ($suspiciousUserAgents as $agent) {
            if (stripos($userAgent, $agent) !== false) {
                return true;
            }
        }

        // Check for suspicious patterns in URL
        $fullUrl = $path . '?' . $query;
        foreach ($suspiciousPatterns as $pattern) {
            if (preg_match($pattern, $fullUrl)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Enhanced Shieldon Firewall
     */
    private function processShieldonFirewall(Request $request, string $ip, array $settings): ?Response
    {
        try {
            $firewall = new Firewall();
            $firewall->setup(storage_path('shieldon'));
            
            // Dynamic configuration based on settings
            $firewall->setConfig([
                'time_unit_quota' => [
                    's' => 3,   // 3 requests per second
                    'm' => (int) $settings['rate_limiting']['requests_per_minute'],
                    'h' => (int) $settings['rate_limiting']['requests_per_hour'],
                ],
                'data_circle' => [
                    's' => 60,  // Store 60 seconds of data
                    'm' => 60,  // Store 60 minutes of data
                    'h' => 24,  // Store 24 hours of data
                ],
            ]);

            // Check if IP is banned
            if ($firewall->getKernel()->isBanned($ip)) {
                Log::warning('DDoS Protection: Shieldon banned IP attempting access: ' . $ip);
                return $this->createBlockedResponse('IP address is banned');
            }

            // Process the request through Shieldon
            $response = $firewall->run();
            
            if ($response->getStatusCode() !== 200) {
                Log::warning('DDoS Protection: Shieldon blocked request from IP: ' . $ip);
                return $response;
            }
        } catch (\Exception $e) {
            Log::error('DDoS Protection: Shieldon error', ['error' => $e->getMessage()]);
        }
        
        return null;
    }

    /**
     * Progressive Rate Limiting
     */
    private function updateProgressiveRateLimit(string $ip): void
    {
        $key = 'progressive_rate:' . $ip;
        $violations = Cache::get($key, 0);
        
        if ($violations > 0) {
            // Increase block duration progressively
            $blockDuration = min(3600 * pow(2, $violations), 86400); // Max 24 hours
            Cache::put($key, $violations + 1, $blockDuration);
        }
    }

    /**
     * Enhanced IP Blocking
     */
    private function blockIp(string $ip, string $reason, int $duration): void
    {
        $blockedIps = Cache::get('blocked_ips', []);
        $blockedIps[$ip] = [
            'reason' => $reason,
            'blocked_at' => now()->toISOString(),
            'expires_at' => now()->addSeconds($duration)->toISOString(),
            'duration' => $duration
        ];
        
        Cache::put('blocked_ips', $blockedIps, $duration);
        
        // Update progressive rate limit
        $progressiveKey = 'progressive_rate:' . $ip;
        $violations = Cache::get($progressiveKey, 0);
        Cache::put($progressiveKey, $violations + 1, $duration);
    }

    /**
     * Create Rate Limit Response
     */
    private function createRateLimitResponse(): Response
    {
        return response()->json([
            'error' => 'Too many requests. Please try again later.',
            'retry_after' => 60,
            'type' => 'rate_limit'
        ], 429);
    }

    /**
     * Create Blocked Response
     */
    private function createBlockedResponse(string $reason): Response
    {
        return response()->json([
            'error' => 'Access denied: ' . $reason,
            'type' => 'blocked'
        ], 403);
    }
}
